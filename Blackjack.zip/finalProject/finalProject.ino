#include <LiquidCrystal.h>
#include <Wire.h>

// Thomas Connolly & Sawyer Lutz

const int rs = 12, en = 11, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);

const int MPU_ADDR = 0x68;

int16_t AcX, AcY, AcZ;

int BUTTON_PIN = 8;

float bias_x = 0, bias_y = 0, bias_z = 0;

byte Heart[8] =
{
  0b00000,
  0b01010,
  0b11111,
  0b11111,
  0b11111,
  0b01110,
  0b00100,
  0b00000
};

byte Spade[8] =
{
  0b00000,
  0b00100,
  0b01110,
  0b11111,
  0b11111,
  0b00100,
  0b01110,
  0b00000
};


byte Diamond[8] =
{
  0b00000,
  0b00100,
  0b01110,
  0b11111,
  0b11111,
  0b01110,
  0b00100,
  0b00000
};

byte Club[8] =
{
  0b00000,
  0b01110,
  0b01110,
  0b11111,
  0b11111,
  0b00100,
  0b01110,
  0b00000
};

byte BackL[8] =
{
  0b11111,
  0b10000,
  0b10100,
  0b10010,
  0b10100,
  0b10010,
  0b10000,
  0b11111
};

byte BackR[8] =
{
  0b11111,
  0b00001,
  0b01001,
  0b00101,
  0b01001,
  0b00101,
  0b00001,
  0b11111
};

byte Ten[8] =
{
  B01000,
  B11000,
  B01000,
  B01010,
  B11101,
  B00101,
  B00101,
  B00010,
};

enum CardFace
{
  A,
  Two,
  Three,
  Four,
  Five,
  Six,
  Seven,
  Eight,
  Nine,
  TenF,
  J,
  Q,
  K
};

enum GameState
{
  MENU,
  PLAYING,
  GAME_OVER
};

enum PlayState
{
  DEALING,
  PLAYER_TURN,
  DEALER_TURN
};

GameState currentGameState = MENU;
PlayState currentPlayState = DEALING; // might not need to init?

bool lastButtonState = HIGH;

struct cardDef{
  char cardSuit; //0 = heart, 1 = spade, 2 = diamond, 3 = club
  CardFace cardFace; //ace king blah blah etc
  int cardValue; //1,2,skip a few, 10, 11
}cardDeck[52];

#define MAX_HAND 10

struct hand{
  cardDef handArray[MAX_HAND];
  int cardCount = 0;
  int lowTotal = 0;
  int highTotal = 0;
  int aceCount = 0;
  bool isDealer = false; // default to false
};

hand dealerHand;
hand playerHand;
//hand playerHand2; // for splits

int deckIndex = 0;

bool dealerTurn = false;

bool gameOver = false;

bool lastX_tilt = false;
bool lastY_tilt = false;

void shuffleDeck()
{
  for(int i = 51; i > 0; i--)
  {
    int r = random(0, i+1);
    cardDef temp = cardDeck[i];
    cardDeck[i] = cardDeck[r];
    cardDeck[r] = temp;
  }
}

int bank = 100;
float bet = 5.00;

void setup() {

  
  Serial.begin(9600);
  Wire.begin();
  Wire.beginTransmission(MPU_ADDR);
  Wire.write(0x6B);
  Wire.write(0);
  Wire.endTransmission(true);
  Serial.println("hi");

  pinMode(BUTTON_PIN, INPUT_PULLUP);
  long sumX = 0, sumY = 0, sumZ = 0;

  for(int i = 0; i < 100; i++)
  {
    Wire.beginTransmission(MPU_ADDR);
    Wire.write(0x3B);
    Wire.endTransmission(false);
    delay(100);
    Wire.requestFrom(MPU_ADDR, 6, true);

    AcX = Wire.read() << 8 | Wire.read();
    AcY = Wire.read() << 8 | Wire.read();
    AcZ = Wire.read() << 8 | Wire.read();

    sumX += AcX;
    sumY += AcY;
    sumZ += AcZ;
    delay(10);
  }

  bias_x = sumX / 100.0;
  bias_y = sumY / 100.0;
  bias_z = sumZ / 100.0;

  int index = 0;
  //randomSeed(analogRead(A0));
  unsigned long seed=0, count=33; //this number generator doesnt work so you have to manually change the seed for it to be random we may have changed the count to a different number than the original code
  while (--count) {
    seed = (seed<<1) | (analogRead(0)&1);
  }
  randomSeed(seed);

  for (int suit = 0; suit < 4; suit++)
  {
    for (int face = 0; face < 13; face++)
    {

      cardDeck[index].cardSuit = suit;
      cardDeck[index].cardFace = face;
      if (face == 0) // Ace
        cardDeck[index].cardValue = 11;
      else if (face >= 9) // J, Q, K
        cardDeck[index].cardValue = 10;
      else
        cardDeck[index].cardValue = face + 1;

      index++;
    }
  }

  shuffleDeck();




  // set up the LCD's number of columns and rows:
  lcd.begin(16, 2);
  // Print a message to the LCD.
  //lcd.print("hello");

  lcd.createChar(0, Heart);
  lcd.createChar(1, Spade);
  lcd.createChar(2, Diamond);
  lcd.createChar(3, Club);

  lcd.createChar(4, BackL);
  lcd.createChar(5, BackR);
  lcd.createChar(6, Ten);

  mainMenu();

}

void loop() {
  // set the cursor to column 0, line 1
  // (note: line 1 is the second row, since counting begins with 0):
  //lcd.setCursor(0, 1);
  // print the number of seconds since reset:
  //lcd.print(millis() / 1000);

  bool X_tilt = false;
  bool Y_tilt = false;

  switch(currentGameState)
  {
    case MENU:
      mainMenu();
      currentGameState = PLAYING;
      currentPlayState = DEALING;
      break;
    case PLAYING:
      switch(currentPlayState)
      {
        case DEALING:
        {
          startGame();
          lastX_tilt = false;
          lastY_tilt = false;
          currentPlayState = PLAYER_TURN;
          break;
        }
        case PLAYER_TURN:
        {
          if(playerHand.cardCount == 2 && dealerHand.cardCount ==2) // start of hand
          {
            if(playerHand.highTotal == 21 && dealerHand.highTotal == 21) // go buy a real lotto ticket
            {
              push();
              currentGameState = GAME_OVER;
              //gameOver = true;
              //return;
            }
            else if(playerHand.highTotal == 21)
            {
              blackjack('P');
              currentGameState = GAME_OVER;
              //return;
            }
            else if(dealerHand.highTotal == 21)
            {
              blackjack('D');
              currentGameState = GAME_OVER;
              //return;
            }
          }

          Wire.beginTransmission(MPU_ADDR);
          //was using 0x6B and nothing was reading so had to search up what to write
          Wire.write(0x3B);
          Wire.endTransmission(false);
          Wire.requestFrom(MPU_ADDR, 6, true);

          AcX = Wire.read() << 8 | Wire.read();
          AcY = Wire.read() << 8 | Wire.read();
          AcZ = Wire.read() << 8 | Wire.read();

          float Xg = (AcX - bias_x) / 16384.0;
          float Yg = (AcY - bias_y) / 16384.0;
          float Zg = (AcZ - bias_z) / 16384.0;

          //Serial.print("Xg: "); Serial.print(Xg, 2);
          //Serial.print(" | Yg: "); Serial.print(Yg, 2);
          //Serial.print(" | Zg: "); Serial.println(Zg, 2);
          X_tilt = abs(Xg) > 0.7;
          Y_tilt = abs(Yg) > 0.7;

          if(Y_tilt)
          {
            //Serial.println("ytilt");
            delay(1000);
            Y_tilt = false;
            currentPlayState = DEALER_TURN;
            //playerStand();
            //return;
          }
          else
          {
            if (X_tilt)
            {
              //Serial.println("xtilt");
              delay(1000);
              X_tilt = false;
              playerHit();
              //return;
            }
            //else digitalWrite(LED_X, LOW);
            
            //else digitalWrite(LED_Y, LOW);
            //delay(200);

            //lastX_tilt = X_tilt;
            //lastY_tilt = Y_tilt;

            // reaches here after each input

            if(playerHand.highTotal > 21) // player busts
            {
              //playerStand();
              bust('P');
              currentGameState = GAME_OVER;
              //return;
            }
            else if(playerHand.highTotal == 21) // player draws 21
            {
              currentGameState = GAME_OVER;
              //playerStand();
              //currentGameState = GAME_OVER;
              //return;
            }
          }
          break;
        }
        case DEALER_TURN:
        {
          //Serial.println("dealerturn");
          revealDealerHand();
          dealerPlay();
          if(dealerHand.highTotal > 21) // dealer busts
          {
            bust('D');
            currentGameState = GAME_OVER;
            //return;
          }
          else if(dealerHand.highTotal > playerHand.highTotal) // dealer wins
          {
            win('D');
            currentGameState = GAME_OVER;
            //return;
          }
          else if(dealerHand.highTotal == playerHand.highTotal) // dealer pushes
          {
            push();
            currentGameState = GAME_OVER;
            //return;
          }
          else if(dealerHand.highTotal < playerHand.highTotal) // dealer loses
          {
            win('P');
            currentGameState = GAME_OVER;
            //return;
          }
          break;
        }
      }
      break;

    case GAME_OVER:
      bool buttonState = digitalRead(BUTTON_PIN);
      if(buttonState == LOW && lastButtonState == HIGH)
      {
        //mainMenu();
        currentGameState = MENU;
        delay(300); // debounce
      }
      lastButtonState = buttonState;
  }

}


void mainMenu()
{
  bool buttonClicked = false;

  lcd.clear();
  lcd.print("Bank: ");
  lcd.print(bank);
  lcd.setCursor(0, 1);
  lcd.print("Bet: ");
  lcd.print(bet);

  while(true) // button click starts new hand
  {
    bool buttonState = digitalRead(BUTTON_PIN);
    if(buttonState == LOW && lastButtonState == HIGH)
    {
      //mainMenu();
      buttonClicked = true;
      delay(300); // debounce
      //continue;
    }
    lastButtonState = buttonState;

    if(buttonClicked == true)
    {
      break;
    }

    float lastbet = bet;
    // read pot & update bet
    int potentVal = analogRead(A2);
    if(potentVal < 256)
    {
      bet = 5.00;
    }
    else if(potentVal < 512)
    {
      bet = 10.00;
    }
    else if(potentVal < 768)
    {
      bet = 25.00;
    }
    else
    {
      bet = 50.00;
    }

    if(bet > bank) // cannot bet more than you have
    {
      bet = bank;
    }

    if(lastbet != bet) // update lcd only if bet has changed
    {
      lcd.setCursor(5,1);
      lcd.print(bet);
    }
  }
}

void startGame()
{
  lcd.clear();

  dealerHand.cardCount = 0;
  dealerHand.lowTotal = 0;
  dealerHand.highTotal = 0;
  dealerHand.aceCount = 0;
  dealerHand.isDealer = true;

  playerHand.cardCount = 0;
  playerHand.lowTotal = 0;
  playerHand.highTotal = 0;
  playerHand.aceCount = 0;

  //dealerTurn = false;
  //gameOver = false;

  delay(2000);
  dealHands();
  displayDealerFlop();
  displayPlayerHand();
}


void dealHands()
{
  for(int i = 0; i<2; i++)
  {
    playerHand.handArray[playerHand.cardCount] = cardDeck[deckIndex];
    playerHand.lowTotal += cardDeck[deckIndex].cardValue;
    playerHand.highTotal += cardDeck[deckIndex].cardValue;
    if(cardDeck[deckIndex].cardValue == 11)
    {
      playerHand.aceCount++;
    }
    if(playerHand.highTotal > 21)
    {
      playerHand.lowTotal = playerHand.highTotal - 10*(playerHand.aceCount);
    }
    playerHand.cardCount++;
    deckIndex++;
    dealerHand.handArray[dealerHand.cardCount] = cardDeck[deckIndex];
    dealerHand.lowTotal += cardDeck[deckIndex].cardValue;
    dealerHand.highTotal += cardDeck[deckIndex].cardValue;
    if(cardDeck[deckIndex].cardValue == 11)
    {
      dealerHand.aceCount++;
    }
    while(dealerHand.highTotal > 21)
    {
      dealerHand.lowTotal = dealerHand.highTotal - 10;
    }
    dealerHand.cardCount++;
    deckIndex++;
  }
}


void displayDealerFlop()
{
  lcd.setCursor(0, 0);
  lcd.print("D:");

  lcd.setCursor(2, 0);
  if(dealerHand.handArray[0].cardFace == 9)
  {
    lcd.write(byte(6));
  }
  else if(dealerHand.handArray[0].cardValue >= 10)
  {
    lcd.print(faceToChar(dealerHand.handArray[0].cardFace));
  }
  else
  {
    lcd.print(dealerHand.handArray[0].cardValue);
  }

  lcd.setCursor(3, 0);
  lcd.write(byte(dealerHand.handArray[0].cardSuit));

  lcd.setCursor(4, 0);
  lcd.write(byte(4));
  lcd.setCursor(5, 0);
  lcd.write(byte(5));

  lcd.setCursor(14,0);
  //lcd.print(dealerHand.highTotal);
  lcd.print("?");
}


void displayPlayerHand()
{
  lcd.setCursor(0, 1);
  lcd.print("P:");

  for(int i = 0; i < playerHand.cardCount; i++)
  {
    lcd.setCursor((i*2)+2, 1);
    if(playerHand.handArray[i].cardFace == 9)
    {
      lcd.write(byte(6));
    }
    else if(playerHand.handArray[i].cardValue >= 10)
    {
      lcd.print(faceToChar(playerHand.handArray[i].cardFace));
    }
    else
    {
      lcd.print(playerHand.handArray[i].cardValue);
    }

    lcd.setCursor((i*2)+3, 1);
    lcd.write(byte(playerHand.handArray[i].cardSuit));
  }

  lcd.setCursor(14,1);
  lcd.print(playerHand.highTotal);
}


void revealDealerHand()
{
  for(int i = 0; i < dealerHand.cardCount; i++)
  {
    lcd.setCursor((i*2)+2, 0);
    if(dealerHand.handArray[i].cardFace == 9)
    {
      lcd.write(byte(6));
    }
    else if(dealerHand.handArray[i].cardValue >= 10)
    {
      lcd.print(faceToChar(dealerHand.handArray[i].cardFace));
    }
    else
    {
      lcd.print(dealerHand.handArray[i].cardValue);
    }

    lcd.setCursor((i*2)+3, 0);
    lcd.write(byte(dealerHand.handArray[i].cardSuit));
  }
  lcd.setCursor(14,0);
  lcd.print(dealerHand.highTotal);
}

void dealerPlay()
{
  while(dealerHand.highTotal < 17) // dealer hits until soft 17 or higher
  {
    //delay(1000);
    dealerHand.handArray[dealerHand.cardCount] = cardDeck[deckIndex];
    dealerHand.lowTotal += cardDeck[deckIndex].cardValue;
    dealerHand.highTotal += cardDeck[deckIndex].cardValue;
    if(cardDeck[deckIndex].cardValue == 11)
    {
      dealerHand.aceCount++;
    }
    if(dealerHand.highTotal > 21)
    {
      dealerHand.lowTotal = dealerHand.highTotal - 10*(dealerHand.aceCount);
      //dealerHand.highTotal = dealerHand.highTotal - (10*(dealerHand.aceCount));
    }
    dealerHand.cardCount++;
    deckIndex++;
    revealDealerHand();
    delay(2000);
  }
}

void playerHit()
{
  delay(1000);
  playerHand.handArray[playerHand.cardCount] = cardDeck[deckIndex];
  playerHand.lowTotal += cardDeck[deckIndex].cardValue;
  playerHand.highTotal += cardDeck[deckIndex].cardValue;
  if(cardDeck[deckIndex].cardValue == 11)
  {
    playerHand.aceCount++;
  }
  if(playerHand.highTotal > 21)
  {
    playerHand.lowTotal = playerHand.highTotal - 10*(playerHand.aceCount);
  }
  playerHand.cardCount++;
  deckIndex++;
  displayPlayerHand();
}

void playerStand()
{
  delay(1000);
  currentPlayState = DEALER_TURN;
  
  
  /*
  //gameOver = true;
  dealerTurn = true;
  revealDealerHand();
  dealerPlay();
  */
}

void playerDouble() // unused
{
  //function to double wager
  playerHit();
  playerStand();
}

void win(char hand)
{
  lcd.clear();
  switch(hand)
  {
    case 'D':
      lcd.print("Dealer Wins");
      bank -= (bet);
      lcd.setCursor(0,1);
      lcd.print("Bank:");
      lcd.print(bank);

      return;
    case 'P':
      lcd.print("You Win");
      bank += (bet*2);
      lcd.setCursor(0,1);
      lcd.print("Bank:");
      lcd.print(bank);

      return;
  }
}

void bust(char hand)
{
  lcd.clear();
  switch(hand)
  {
    case 'D':
      lcd.print("Dealer Busts");
      bank += (bet*2);
      lcd.setCursor(0,1);
      lcd.print("You Win");
      lcd.setCursor(8,1);
      lcd.print("Bank:");
      lcd.print(bank);

      return;
    case 'P':
      lcd.print("You Bust");
      bank -= (bet*2);
      lcd.setCursor(0,1);
      lcd.print("Dealer Wins");
      lcd.setCursor(8,1);
      lcd.print("Bank:");
      lcd.print(bank);

      return;
  }
}

void push()
{
  lcd.clear();
  lcd.print("Push");
  lcd.setCursor(0,1);
  lcd.print("Nobody Wins");
}

void blackjack(char hand)
{
  switch(hand)
  {
    case 'D':
      revealDealerHand();
      lcd.setCursor(7, 0);
      lcd.print("BLCKJCK");
      delay(2000);
      win('D');
      return;
    case 'P':
      lcd.setCursor(7, 1);
      lcd.print("BLCKJCK");
      delay(2000);
      win('P');
      return;
  }
}

char faceToChar(CardFace face)
{
  switch(face)
  {
    case A:
      return 'A';
    case J:
      return 'J';
    case Q:
      return 'Q';
    case K:
      return 'K';
    default: return ' '; // not used for numbers
  }
}




